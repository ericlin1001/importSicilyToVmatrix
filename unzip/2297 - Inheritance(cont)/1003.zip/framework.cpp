#include <iostream>
using namespace std;

#include "source.cpp"

int main()
{
//	freopen("test01.in", "r", stdin);
//	freopen("test01.out", "w", stdout);
    D d;
    return 0;
}