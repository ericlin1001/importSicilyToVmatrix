// =====================
// framework source code
// =====================
#include <iostream>
#include <iomanip>
#include<string>
#include<algorithm>
#include "source.cpp"
using namespace std;

int main() {
    string str;
    while(cin >> str)
    {
   	  string s = sort(str);
      cout 
         //<< str << " " 
         << s << endl;
    }
	return 0;
}
                                
