#include "source.cpp"
int main()
{
	{
	Weekend end;
	Workday day;
    }
}